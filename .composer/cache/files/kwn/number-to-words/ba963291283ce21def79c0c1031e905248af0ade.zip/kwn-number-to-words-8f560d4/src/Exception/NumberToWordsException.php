<?php

namespace NumberToWords\Exception;

class NumberToWordsException extends \Exception
{
}
