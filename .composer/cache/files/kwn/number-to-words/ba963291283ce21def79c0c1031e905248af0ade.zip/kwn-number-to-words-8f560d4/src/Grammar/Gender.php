<?php

namespace NumberToWords\Grammar;

class Gender
{
    const GENDER_MASCULINE = 0;
    const GENDER_FEMININE = 1;
    const GENDER_NEUTER = 2;
    const GENDER_ABSTRACT = 3;
}
