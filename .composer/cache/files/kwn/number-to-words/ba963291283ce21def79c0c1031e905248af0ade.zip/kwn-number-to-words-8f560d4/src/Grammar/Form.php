<?php

namespace NumberToWords\Grammar;

class Form
{
    const SINGULAR = 'singular';
    const PLURAL = 'plural';
}
