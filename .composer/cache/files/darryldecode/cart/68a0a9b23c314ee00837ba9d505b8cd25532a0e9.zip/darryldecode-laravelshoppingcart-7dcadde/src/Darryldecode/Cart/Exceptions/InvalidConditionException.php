<?php namespace Darryldecode\Cart\Exceptions;

/**
 * Created by PhpStorm.
 * User: darryl
 * Date: 1/15/2015
 * Time: 9:24 PM
 */

class InvalidConditionException extends \Exception {

}