<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Exclusion list
    |--------------------------------------------------------------------------
    |
    | This is a list of exclusions for words or phrases where the original
    | form of the word has the same spelling in a given language.
    |
    */

    'Email',
    'Oh no',
    'Editor',
    'Password',
    'Dashboard',
];
