<?php

namespace Composer\Downloader;

class MaxFileSizeExceededException extends TransportException
{
}
