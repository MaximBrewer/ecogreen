<?php

return [

    /*
     * Defines the default autohide parameter
     */
    'autohide' => false,
    /*
     * Defines the position of the toast on the window
     */
    // "top" or "bottom"
    "position_x" => 'top',
    // "left" or "right"
    "position_y" => 'right',


];
