<?php

return [
    'tables' => [
        // table names for generating bread seeders.
    ],
];
